 

   $(document).ready(function(){ 

//     $(".logo-main").slideDown(2000);

 

 $(function() {
  $('.loader').fadeOut();
});

});


// $(document).ready(function(){
// 	$("div.logoimg").click(function()	{
// 		$("div").hide();
// 	});
// });


 